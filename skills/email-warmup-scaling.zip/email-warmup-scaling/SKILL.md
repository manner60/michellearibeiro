# Advanced Email Warm-Up & Autonomous Scaling Engine

## PURPOSE
To intelligently manage email warm-up, inbox placement optimization, and multi-inbox scaling while protecting sender reputation and maximizing deliverability.

---

## INPUT VARIABLES

### Core Metrics
- `warmup_day` (integer)
- `current_daily_volume` (integer)
- `open_rate` (percentage)
- `reply_rate` (percentage)
- `bounce_rate` (percentage)
- `spam_complaints` (integer)

### Advanced Metrics (if available)
- `inbox_placement_rate` (percentage)
- `positive_reply_rate` (percentage)
- `unsubscribe_rate` (percentage)

### System Variables
- `number_of_inboxes` (integer)
- `list_type` ("cold" OR "warm")
- `day_of_week` ("Mon"–"Sun")

---

## CORE OBJECTIVE

Scale email volume safely while:
- Maintaining strong inbox placement
- Avoiding spam flags and reputation damage
- Dynamically adjusting based on engagement signals
- Coordinating volume across multiple inboxes

---

## GLOBAL RULES

1. One send per inbox per day
2. Consistency is mandatory (no skipped days)
3. Never scale aggressively without performance validation
4. Protect domain reputation above all else
5. When in doubt → HOLD or REDUCE

---

## DAILY SCALING LOGIC

### Phase-Based Increase Limits

```
IF warmup_day <= 14:
  max_increase_per_inbox = 5

ELSE IF warmup_day BETWEEN 15 AND 21:
  max_increase_per_inbox = 10

ELSE:
  max_increase_per_inbox = 15
```

### 20% RULE (HARD CAP)

```
max_allowed_increase = current_daily_volume * 0.20
allowed_increase = MIN(max_increase_per_inbox, max_allowed_increase)
```

---

## PERFORMANCE VALIDATION LAYER

### CRITICAL FAILURE CONDITIONS

```
IF spam_complaints > 0:
  ACTION = "FREEZE"
  next_daily_volume = current_daily_volume
  FLAG = "Spam complaint detected"

IF bounce_rate > 5%:
  ACTION = "EMERGENCY REDUCE"
  next_daily_volume = current_daily_volume * 0.7
  FLAG = "High bounce rate"
```

### MODERATE RISK CONDITIONS

```
IF open_rate < 35% OR bounce_rate > 3%:
  ACTION = "HOLD"
  next_daily_volume = current_daily_volume
  FLAG = "Engagement below threshold"
```

### INBOX PLACEMENT CONTROL (IF AVAILABLE)

```
IF inbox_placement_rate < 70%:
  ACTION = "HOLD"
  FLAG = "Poor inbox placement"

IF inbox_placement_rate < 60%:
  ACTION = "REDUCE"
  next_daily_volume = current_daily_volume * 0.8
  FLAG = "Critical inbox placement issue"
```

---

## POSITIVE SCALING CONDITIONS

```
IF:
  open_rate >= 35%
  bounce_rate <= 3%
  spam_complaints == 0
  AND (if available) inbox_placement_rate >= 70%

THEN:
  ACTION = "SCALE"
  next_daily_volume = current_daily_volume + allowed_increase
```

---

## ENGAGEMENT MOMENTUM BOOST

```
IF reply_rate increasing over 3 days:
  allowed_increase = allowed_increase * 1.25
  (still respecting 20% cap)
```

---

## DAY-OF-WEEK LOGIC

```
IF day_of_week IN ("Sat", "Sun"):

  IF list_type == "cold":
    next_daily_volume = current_daily_volume * 0.8
    ACTION = "WEEKEND THROTTLE"

  IF list_type == "warm":
    ACTION = "NORMAL SEND"
```

---

## MULTI-INBOX SCALING LOGIC

```
total_system_volume = next_daily_volume * number_of_inboxes
```

**RULES:**
- Keep volume evenly distributed across inboxes
- Do NOT scale one inbox faster than others
- If one inbox shows poor metrics → isolate and reduce only that inbox

---

## LIST-TYPE ADAPTATION

```
IF list_type == "cold":
  - Prioritize open_rate and reply_rate heavily
  - Require stricter thresholds before scaling

IF list_type == "warm":
  - Allow slightly faster scaling
  - Open rate threshold can drop to 30%
```

---

## DROP DETECTION LOGIC

```
IF open_rate drops by >10% over 48 hours:
  ACTION = "STABILIZE"
  next_daily_volume = current_daily_volume
  HOLD for 2 days before next increase
```

---

## SENDING CONSISTENCY RULES

- Send at same time daily (+/- 1 hour)
- No batching during warm-up
- No sudden spikes
- Maintain consistent messaging style

---

## REPUTATION PROTECTION FAILAFE

```
IF:
  spam_complaints >= 2 OR
  bounce_rate > 6%

THEN:
  ACTION = "HARD REDUCE"
  next_daily_volume = current_daily_volume * 0.5
  FLAG = "Severe reputation risk"
```

---

## OUTPUT FORMAT

Return:
- `next_daily_volume_per_inbox`
- `total_system_volume`
- `action_taken`
- `reasoning`
- `risk_flag`

### Example Output

```
next_daily_volume_per_inbox: 40
total_system_volume: 120
action_taken: SCALE
reasoning: Strong engagement and safe inbox placement
risk_flag: NONE
```

---

## CRITICAL REMINDERS

- **NEVER** exceed planned volume without explicit approval
- **ALWAYS** confirm parameters before acting on live campaigns
- **PROTECT** domain reputation above speed or convenience
- **WHEN IN DOUBT** → HOLD or REDUCE

---

*Skill created: March 31, 2026*
