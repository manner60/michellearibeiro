# MintBird / Poplinks API Skill

## Purpose

Use the MintBird API to create, update, and manage:
- Poplinks
- Lead pages
- Bridge pages
- Confirmation pages
- Sales funnels
- Sales pages
- Products
- Categories
- Stats and reporting
- AI-generated sales pages

This skill acts as a structured API operator that:
1. Understands the user's marketing asset request
2. Maps it to the correct MintBird endpoint
3. Validates required parameters
4. Makes the API request
5. Returns a clean human-readable result
6. Surfaces any validation or API errors clearly

---

## Configuration

### Required Credentials
Store your MintBird API key in:
`credentials/titanium-api-keys.txt`

Format:
```
MintBird API Key: YOUR_API_KEY_HERE
```

### Base URL
Default: `https://api.poplinks.io/api/ai`

---

## Core Behavior

### 1. Detect Intent
Map requests to action types:
- create poplink
- update poplink
- list domains/groups/vendors/templates
- create/update lead page
- create/update bridge page
- create/update funnel
- create/update sales page
- generate AI sales page
- link product to sales page
- fetch stats/leads/products
- manage categories

### 2. Resolve Dependencies First
Before creating assets, fetch required supporting IDs:
- domains
- groups
- vendors
- templates
- categories
- products
- funnels

### 3. Validate Before Request
Do not send incomplete API calls. Check for:
- Required names
- Valid URLs
- Valid domain type
- Required IDs
- Valid page types
- Required prompt length for AI generation

### 4. Ask Only When Essential
If a user says "Create me a poplink for this offer" without specifying domain/group/vendor:
- Fetch available domains/groups/vendors
- Pick the safest default if only one obvious option exists
- Otherwise ask for the missing choice

### 5. Ask About Domain Preference (Products & Links)
When creating products or links, ALWAYS ask:
- "Which domain would you like to use?"
- Fetch and present available options:
  - System domains (redeyedeal.com)
  - Personal domains (aiopenclawskills.com or your custom domain)
- Wait for user selection before proceeding

### 6. Ask About Product Images
When creating products, ALWAYS ask:
- "Would you like to upload an image for this product?"
- If yes:
  - Ask for image URL (for URL-based upload)
  - Or ask for file path (for file upload)
  - Use `PUT /products/:id/image/url` for URL uploads
  - Use multipart/form-data for file uploads
- If no: Proceed without image

### 7. Return Structured Results

### 5. Return Structured Results
Always return:
- Action completed
- Endpoint used
- Key IDs created or updated
- Public URLs or slugs if returned
- Next suggested step

---

## API Reference

### Authentication
```
Authorization: Bearer {{api_key}}
```

### Common Errors
- 401 Unauthorized - Check API key
- 404 Resource not found - Verify ID exists
- 422 Validation error - Missing or invalid fields
- 500 Server error - Retry or contact support

---

## Endpoints

### Helpers (Fetch First)

**GET /system-domains** - List available system domains
**GET /domains** - List personal domains
**GET /groups** - List link groups
**GET /vendors** - List vendors
**GET /templates** - List page templates
**GET /categories** - List categories

### Poplinks

**POST /poplinks** - Create tracked link
Required: name, destination_url, visible_url, domain_id
Optional: domain_type, group_id, vendor_id, is_clocked, dates

**PUT /poplinks/:id** - Update link
**GET /poplinks** - List all links
**GET /poplinks/:id** - Get single link
**GET /poplinks/:id/clicks** - Get click stats

### Lead Pages

**POST /lead-pages** - Create landing page
Required: name
Optional: template_id, category_id

**PUT /lead-pages/:id/url** - Update URL
**PUT /lead-pages/:id/rename** - Rename
**PUT /lead-pages/:id/headline** - Update headline
**PUT /lead-pages/:id/template** - Change template
**POST /lead-pages/:id/clone** - Duplicate page

### Bridge Pages

**POST /bridge-pages** - Create bridge page
**PUT /bridge-pages/:id/** - Update fields

### Confirmation Pages

**GET /conf-pages** - List confirmation pages
**PUT /conf-pages/:id/headline** - Update headline
**PUT /conf-pages/:id/redirect-url** - Set redirect

### Sales Funnels

**POST /sales-funnels** - Create funnel
Required: name
Optional: category_id

**PUT /sales-funnels/:id** - Update funnel
**DELETE /sales-funnels/:id** - Delete funnel
**GET /sales-funnels/:id/steps** - List funnel steps
**POST /steps** - Add step to funnel

### Sales Pages

**POST /sales-pages** - Create sales page
Required: name
Optional: category_id, sub_type (salespage, upsell, downsell)

**PUT /sales-pages/:id** - Update sales page
**DELETE /sales-pages/:id** - Delete sales page
**POST /sales-pages/link-product** - Link product to page

### AI Generation

**POST /sales-page/generate** - Generate AI sales page
Required: prompt, name
Optional: sub_type, pipeline (json, html, htmlblock)

**GET /sales-page/generation-status** - Check generation status

### Products

**GET /products** - List products
**POST /products** - Create product
**PUT /products/:id** - Update product
**PUT /products/:id/redirect-settings** - Set redirect URL
**PUT /products/:id/image** - Upload product image (multipart/form-data)
**PUT /products/:id/image/url** - Set product image by URL

**Image Upload Workflow:**
1. Ask user: "Would you like to add an image to this product?"
2. If yes, ask: "Image URL or file path?"
3. Use appropriate endpoint based on response
4. Confirm successful upload

### Stats

**GET /stats/overview** - Dashboard overview
**GET /stats/funnel** - Funnel performance
**GET /leads** - Captured leads

---

## Usage Examples

### Create a Poplink
```
User: "Create a poplink called Webinar Redirect to https://example.com/webinar"

Skill will:
1. ASK: "Which domain would you like to use?"
   - Fetch and display available system/personal domains
   - Wait for user selection
2. POST /poplinks with:
   - name: "Webinar Redirect"
   - destination_url: "https://example.com/webinar"
   - visible_url: "webinar-redirect"
   - domain_id: [user-selected domain]
```

### Create a Product
```
User: "Create a product called SEO Course for $97"

Skill will:
1. ASK: "Which domain should this product use?"
   - Display available domains
   - Wait for user selection
2. ASK: "Would you like to upload an image for this product?"
   - If yes: Ask for image URL or file path
3. POST /products with product details
4. If image provided: PUT /products/:id/image/url or upload file
5. Return product details with checkout URL
```

### Generate AI Sales Page
```
User: "Generate a sales page for a restaurant tax credit course"

Skill will:
1. POST /sales-page/generate with:
   - name: "Restaurant Tax Credit Sales Page"
   - prompt: "Create a sales page for restaurant owners..."
   - sub_type: "salespage"
2. Return job_key for status tracking
```

### Create Funnel + Sales Page
```
User: "Create a funnel called FICA Offer and add a sales page"

Skill will:
1. POST /sales-funnels (create funnel)
2. POST /sales-pages (create sales page)
3. Return both IDs and suggest next steps
```

---

## Response Format

Always respond with:

### Action
What was requested

### Endpoint
Method + endpoint used

### Inputs
Key fields sent

### Result
Success or failure summary

### Output
IDs, names, URLs, job keys

### Next Step
Recommended follow-up action

---

## Error Handling

When errors occur:
1. Show the endpoint called
2. Show the status code
3. Summarize error in plain English
4. Preserve original API response when useful
5. Suggest corrective action

---

## Safety Rules

1. **Never invent IDs** - Always fetch helper data first
2. **Preserve user intent** - Don't rewrite marketing content unless asked
3. **Confirm destructive actions** - Summarize before delete operations
4. **Prefer incremental updates** - Use specific endpoints for single field changes
5. **Surface useful outputs** - Always return IDs, URLs, and next steps

---

## Files

- **SKILL.md** - This documentation
- **scripts/mintbird-api.js** - Core API functions (to be created)
- **scripts/helpers.js** - Utility functions (to be created)

---

## Version

1.0.0 - Initial release with full MintBird API coverage
